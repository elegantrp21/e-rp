# DevelNext-Updater
Система обновлений для проектов DevelNext
![Screenshot](https://tssaltan.ru/files/2018/02/updater-develnext-720x340.png)

### Содержимое репозитория
- **bundle** - пакет с необходимым функционалом
- **project-updater** - исходники проекта Updater, который отвечает за обновление программы, его необходимо собрать в Updater.jar
- **project-updateMe** - исходники демо проекта
- **demo** - собственно демонстрация, запускаем <strong>UpdateMe.jar</strong>

**Подробности в статье [https://tssaltan.ru/1531.develnext-updater/](https://tssaltan.ru/1531.develnext-updater/)**