<?php
namespace app\modules;

use bundle\updater\GitHubUpdater;
use std, gui, framework, app;
use php\gui\framework\ScriptEvent; 


class AppModule extends AbstractModule
{

}